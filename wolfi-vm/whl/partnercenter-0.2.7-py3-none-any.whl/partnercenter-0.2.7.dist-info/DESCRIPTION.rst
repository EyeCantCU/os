Microsoft Azure CLI 'partnercenter' Extension
==========================================

This package is for the 'partnercenter' extension.
i.e. 'az partnercenter'

.. :changelog:

Release History
===============

0.1.0
++++++
* Initial release.
